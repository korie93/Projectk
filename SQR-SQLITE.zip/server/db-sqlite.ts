import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import * as schema from "../shared/schema-sqlite";
import path from "path";
import fs from "fs";

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "sqr.db");
const sqlite = new Database(dbPath);

sqlite.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    is_banned INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS imports (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    filename TEXT NOT NULL,
    created_at INTEGER,
    is_deleted INTEGER DEFAULT 0,
    created_by TEXT
  );

  CREATE TABLE IF NOT EXISTS data_rows (
    id TEXT PRIMARY KEY,
    import_id TEXT NOT NULL,
    json_data TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS user_activity (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    role TEXT NOT NULL,
    pc_name TEXT,
    browser TEXT,
    fingerprint TEXT,
    ip_address TEXT,
    login_time INTEGER,
    logout_time INTEGER,
    last_activity_time INTEGER,
    is_active INTEGER DEFAULT 1,
    logout_reason TEXT
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    action TEXT NOT NULL,
    performed_by TEXT NOT NULL,
    target_user TEXT,
    target_resource TEXT,
    details TEXT,
    timestamp INTEGER
  );

  CREATE TABLE IF NOT EXISTS backups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at INTEGER,
    created_by TEXT NOT NULL,
    backup_data TEXT NOT NULL,
    metadata TEXT
  );
`);

export const sqliteDb = drizzle(sqlite, { schema });
export { sqlite };
