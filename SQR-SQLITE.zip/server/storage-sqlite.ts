import {
  type User,
  type InsertUser,
  type Import,
  type InsertImport,
  type DataRow,
  type InsertDataRow,
  type UserActivity,
  type InsertUserActivity,
  type AuditLog,
  type InsertAuditLog,
  type Backup,
  type InsertBackup,
  users,
  imports,
  dataRows,
  userActivity,
  auditLogs,
  backups,
} from "../shared/schema-sqlite";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";
import { sqliteDb } from "./db-sqlite";
import { eq, desc, and, or, gte, lte } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBan(username: string, isBanned: boolean): Promise<User | undefined>;

  createImport(data: InsertImport & { createdBy?: string }): Promise<Import>;
  getImports(): Promise<Import[]>;
  getImportById(id: string): Promise<Import | undefined>;
  updateImportName(id: string, name: string): Promise<Import | undefined>;
  deleteImport(id: string): Promise<boolean>;

  createDataRow(data: InsertDataRow): Promise<DataRow>;
  getDataRowsByImport(importId: string): Promise<DataRow[]>;
  searchDataRows(query: string): Promise<DataRow[]>;
  advancedSearchDataRows(
    filters: Array<{ field: string; operator: string; value: string }>,
    logic: "AND" | "OR"
  ): Promise<DataRow[]>;
  getAllColumnNames(): Promise<string[]>;

  createActivity(data: InsertUserActivity): Promise<UserActivity>;
  updateActivity(id: string, data: Partial<UserActivity>): Promise<UserActivity | undefined>;
  getActivityById(id: string): Promise<UserActivity | undefined>;
  getActiveActivities(): Promise<UserActivity[]>;
  getAllActivities(): Promise<UserActivity[]>;
  deleteActivity(id: string): Promise<boolean>;
  getFilteredActivities(filters: {
    status?: string[];
    username?: string;
    ipAddress?: string;
    browser?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<UserActivity[]>;
  deactivateUserActivities(username: string, reason?: string): Promise<void>;
  deactivateUserSessionsByFingerprint(username: string, fingerprint: string): Promise<void>;
  getBannedUsers(): Promise<Array<User & { banInfo?: { ipAddress: string | null; browser: string | null; bannedAt: Date | null } }>>;

  createAuditLog(data: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(): Promise<AuditLog[]>;

  createBackup(data: InsertBackup): Promise<Backup>;
  getBackups(): Promise<Backup[]>;
  getBackupById(id: string): Promise<Backup | undefined>;
  deleteBackup(id: string): Promise<boolean>;
  getBackupDataForExport(): Promise<{
    imports: Import[];
    dataRows: DataRow[];
    users: Array<{ username: string; role: string; isBanned: boolean | null; passwordHash: string }>;
    auditLogs: AuditLog[];
  }>;
  restoreFromBackup(backupData: {
    imports: Import[];
    dataRows: DataRow[];
    users: Array<{ username: string; role: string; isBanned: boolean | null; passwordHash?: string }>;
    auditLogs: AuditLog[];
  }): Promise<{ success: boolean; stats: { imports: number; dataRows: number; users: number; auditLogs: number } }>;
}

export class SQLiteStorage implements IStorage {
  constructor() {
    this.seedDefaultUsers();
  }

  private async seedDefaultUsers() {
    const defaultUsers = [
      { username: "superuser", password: "0441024k", role: "superuser" },
      { username: "admin1", password: "admin123", role: "admin" },
      { username: "user1", password: "user123", role: "user" },
    ];

    for (const user of defaultUsers) {
      const existing = await this.getUserByUsername(user.username);
      if (!existing) {
        const hashedPassword = await bcrypt.hash(user.password, 10);
        const id = randomUUID();
        sqliteDb.insert(users).values({
          id,
          username: user.username,
          password: hashedPassword,
          role: user.role,
          isBanned: false,
        }).run();
      }
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = sqliteDb.select().from(users).where(eq(users.id, id)).limit(1).all();
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = sqliteDb.select().from(users).where(eq(users.username, username)).limit(1).all();
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(user.password, 10);
    sqliteDb.insert(users).values({
      id,
      username: user.username,
      password: hashedPassword,
      role: user.role || "user",
      isBanned: false,
    }).run();
    const result = sqliteDb.select().from(users).where(eq(users.id, id)).limit(1).all();
    return result[0];
  }

  async updateUserBan(username: string, isBanned: boolean): Promise<User | undefined> {
    sqliteDb.update(users).set({ isBanned }).where(eq(users.username, username)).run();
    const result = sqliteDb.select().from(users).where(eq(users.username, username)).limit(1).all();
    return result[0];
  }

  async createImport(data: InsertImport & { createdBy?: string }): Promise<Import> {
    const id = randomUUID();
    const now = new Date();
    sqliteDb.insert(imports).values({
      id,
      name: data.name,
      filename: data.filename,
      createdBy: data.createdBy || null,
      createdAt: now,
      isDeleted: false,
    }).run();
    const result = sqliteDb.select().from(imports).where(eq(imports.id, id)).limit(1).all();
    return result[0];
  }

  async getImports(): Promise<Import[]> {
    return sqliteDb.select().from(imports).where(eq(imports.isDeleted, false)).orderBy(desc(imports.createdAt)).all();
  }

  async getImportById(id: string): Promise<Import | undefined> {
    const result = sqliteDb.select().from(imports).where(and(eq(imports.id, id), eq(imports.isDeleted, false))).limit(1).all();
    return result[0];
  }

  async updateImportName(id: string, name: string): Promise<Import | undefined> {
    sqliteDb.update(imports).set({ name }).where(eq(imports.id, id)).run();
    return this.getImportById(id);
  }

  async deleteImport(id: string): Promise<boolean> {
    sqliteDb.update(imports).set({ isDeleted: true }).where(eq(imports.id, id)).run();
    return true;
  }

  async createDataRow(data: InsertDataRow): Promise<DataRow> {
    const id = randomUUID();
    sqliteDb.insert(dataRows).values({
      id,
      importId: data.importId,
      jsonData: data.jsonData,
    }).run();
    const result = sqliteDb.select().from(dataRows).where(eq(dataRows.id, id)).limit(1).all();
    return result[0];
  }

  async getDataRowsByImport(importId: string): Promise<DataRow[]> {
    return sqliteDb.select().from(dataRows).where(eq(dataRows.importId, importId)).all();
  }

  async searchDataRows(query: string): Promise<DataRow[]> {
    const lowerQuery = query.toLowerCase();
    const activeImports = await this.getImports();
    const activeImportIds = new Set(activeImports.map((imp) => imp.id));
    
    const allRows = sqliteDb.select().from(dataRows).all();
    return allRows.filter((row) => {
      if (!activeImportIds.has(row.importId)) return false;
      return row.jsonData.toLowerCase().includes(lowerQuery);
    });
  }

  async advancedSearchDataRows(
    filters: Array<{ field: string; operator: string; value: string }>,
    logic: "AND" | "OR"
  ): Promise<DataRow[]> {
    const activeImports = await this.getImports();
    const activeImportIds = new Set(activeImports.map((imp) => imp.id));
    
    const allRows = sqliteDb.select().from(dataRows).all();
    const results: DataRow[] = [];

    for (const row of allRows) {
      if (!activeImportIds.has(row.importId)) continue;

      try {
        const data = JSON.parse(row.jsonData);
        const matches = filters.map((filter) => {
          const fieldValue = String(data[filter.field] || "").toLowerCase();
          const searchValue = filter.value.toLowerCase();

          switch (filter.operator) {
            case "contains":
              return fieldValue.includes(searchValue);
            case "equals":
              return fieldValue === searchValue;
            case "notEquals":
              return fieldValue !== searchValue;
            case "startsWith":
              return fieldValue.startsWith(searchValue);
            case "endsWith":
              return fieldValue.endsWith(searchValue);
            case "greaterThan":
              return parseFloat(fieldValue) > parseFloat(searchValue);
            case "lessThan":
              return parseFloat(fieldValue) < parseFloat(searchValue);
            case "greaterThanOrEqual":
              return parseFloat(fieldValue) >= parseFloat(searchValue);
            case "lessThanOrEqual":
              return parseFloat(fieldValue) <= parseFloat(searchValue);
            case "isEmpty":
              return fieldValue.trim() === "";
            case "isNotEmpty":
              return fieldValue.trim() !== "";
            default:
              return fieldValue.includes(searchValue);
          }
        });

        const isMatch = logic === "AND" ? matches.every(Boolean) : matches.some(Boolean);
        if (isMatch) {
          results.push(row);
        }
      } catch {
        continue;
      }
    }

    return results;
  }

  async getAllColumnNames(): Promise<string[]> {
    const columnSet = new Set<string>();
    const activeImports = await this.getImports();
    const activeImportIds = new Set(activeImports.map((imp) => imp.id));

    const allRows = sqliteDb.select().from(dataRows).all();
    for (const row of allRows) {
      if (!activeImportIds.has(row.importId)) continue;

      try {
        const data = JSON.parse(row.jsonData);
        Object.keys(data).forEach((key) => columnSet.add(key));
      } catch {
        continue;
      }
    }

    return Array.from(columnSet).sort();
  }

  async createActivity(data: InsertUserActivity): Promise<UserActivity> {
    const id = randomUUID();
    const now = new Date();
    sqliteDb.insert(userActivity).values({
      id,
      username: data.username,
      role: data.role,
      pcName: data.pcName || null,
      browser: data.browser || null,
      fingerprint: data.fingerprint || null,
      ipAddress: data.ipAddress || null,
      loginTime: now,
      logoutTime: null,
      lastActivityTime: now,
      isActive: true,
      logoutReason: null,
    }).run();
    const result = sqliteDb.select().from(userActivity).where(eq(userActivity.id, id)).limit(1).all();
    return result[0];
  }

  async updateActivity(id: string, data: Partial<UserActivity>): Promise<UserActivity | undefined> {
    const updateData: any = {};
    if (data.lastActivityTime !== undefined) updateData.lastActivityTime = data.lastActivityTime;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;
    if (data.logoutTime !== undefined) updateData.logoutTime = data.logoutTime;
    if (data.logoutReason !== undefined) updateData.logoutReason = data.logoutReason;
    
    if (Object.keys(updateData).length > 0) {
      sqliteDb.update(userActivity).set(updateData).where(eq(userActivity.id, id)).run();
    }
    const result = sqliteDb.select().from(userActivity).where(eq(userActivity.id, id)).limit(1).all();
    return result[0];
  }

  async getActivityById(id: string): Promise<UserActivity | undefined> {
    const result = sqliteDb.select().from(userActivity).where(eq(userActivity.id, id)).limit(1).all();
    return result[0];
  }

  async getActiveActivities(): Promise<UserActivity[]> {
    return sqliteDb.select().from(userActivity).where(eq(userActivity.isActive, true)).orderBy(desc(userActivity.loginTime)).all();
  }

  async getAllActivities(): Promise<UserActivity[]> {
    return sqliteDb.select().from(userActivity).orderBy(desc(userActivity.loginTime)).all();
  }

  async deleteActivity(id: string): Promise<boolean> {
    sqliteDb.delete(userActivity).where(eq(userActivity.id, id)).run();
    return true;
  }

  private computeActivityStatus(activity: UserActivity): string {
    if (!activity.isActive) {
      if (activity.logoutReason === "KICKED") return "KICKED";
      if (activity.logoutReason === "BANNED") return "BANNED";
      return "LOGOUT";
    }
    if (activity.lastActivityTime) {
      const lastActive = new Date(activity.lastActivityTime).getTime();
      const now = Date.now();
      const diffMins = Math.floor((now - lastActive) / 60000);
      if (diffMins >= 5) return "IDLE";
    }
    return "ONLINE";
  }

  async getFilteredActivities(filters: {
    status?: string[];
    username?: string;
    ipAddress?: string;
    browser?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<UserActivity[]> {
    let activities = sqliteDb.select().from(userActivity).orderBy(desc(userActivity.loginTime)).all();

    if (filters.username) {
      const searchTerm = filters.username.toLowerCase();
      activities = activities.filter((a) => a.username.toLowerCase().includes(searchTerm));
    }

    if (filters.ipAddress) {
      const searchTerm = filters.ipAddress.toLowerCase();
      activities = activities.filter((a) => a.ipAddress?.toLowerCase().includes(searchTerm));
    }

    if (filters.browser) {
      const searchTerm = filters.browser.toLowerCase();
      activities = activities.filter((a) => a.browser?.toLowerCase().includes(searchTerm));
    }

    if (filters.dateFrom) {
      activities = activities.filter((a) => {
        if (!a.loginTime) return false;
        return new Date(a.loginTime) >= filters.dateFrom!;
      });
    }

    if (filters.dateTo) {
      const endOfDay = new Date(filters.dateTo);
      endOfDay.setHours(23, 59, 59, 999);
      activities = activities.filter((a) => {
        if (!a.loginTime) return false;
        return new Date(a.loginTime) <= endOfDay;
      });
    }

    if (filters.status && filters.status.length > 0) {
      activities = activities.filter((a) => {
        const status = this.computeActivityStatus(a);
        return filters.status!.includes(status);
      });
    }

    return activities;
  }

  async deactivateUserActivities(username: string, reason?: string): Promise<void> {
    const now = new Date();
    const updateData: any = { isActive: false, logoutTime: now };
    if (reason) updateData.logoutReason = reason;
    
    const lowerUsername = username.toLowerCase();
    const allActivities = sqliteDb.select().from(userActivity).where(eq(userActivity.isActive, true)).all();
    
    for (const activity of allActivities) {
      if (activity.username.toLowerCase() === lowerUsername) {
        sqliteDb.update(userActivity).set(updateData).where(eq(userActivity.id, activity.id)).run();
      }
    }
  }

  async deactivateUserSessionsByFingerprint(username: string, fingerprint: string): Promise<void> {
    const now = new Date();
    const lowerUsername = username.toLowerCase();
    const allActivities = sqliteDb.select().from(userActivity).where(eq(userActivity.isActive, true)).all();
    
    for (const activity of allActivities) {
      if (activity.username.toLowerCase() === lowerUsername && activity.fingerprint === fingerprint) {
        sqliteDb.update(userActivity).set({
          isActive: false,
          logoutTime: now,
          logoutReason: "NEW_SESSION",
        }).where(eq(userActivity.id, activity.id)).run();
      }
    }
  }

  async getBannedUsers(): Promise<Array<User & { banInfo?: { ipAddress: string | null; browser: string | null; bannedAt: Date | null } }>> {
    const bannedUsers = sqliteDb.select().from(users).where(eq(users.isBanned, true)).all();
    
    const enrichedUsers = bannedUsers.map((user) => {
      const lastBannedActivity = sqliteDb
        .select()
        .from(userActivity)
        .where(eq(userActivity.logoutReason, "BANNED"))
        .orderBy(desc(userActivity.logoutTime))
        .all()
        .filter(a => a.username.toLowerCase() === user.username.toLowerCase())[0];
      
      const banInfo = lastBannedActivity
        ? {
            ipAddress: lastBannedActivity.ipAddress,
            browser: lastBannedActivity.browser,
            bannedAt: lastBannedActivity.logoutTime,
          }
        : undefined;
      
      return { ...user, banInfo };
    });
    
    return enrichedUsers;
  }

  async createAuditLog(data: InsertAuditLog): Promise<AuditLog> {
    const id = randomUUID();
    const now = new Date();
    sqliteDb.insert(auditLogs).values({
      id,
      action: data.action,
      performedBy: data.performedBy,
      targetUser: data.targetUser || null,
      targetResource: data.targetResource || null,
      details: data.details || null,
      timestamp: now,
    }).run();
    const result = sqliteDb.select().from(auditLogs).where(eq(auditLogs.id, id)).limit(1).all();
    return result[0];
  }

  async getAuditLogs(): Promise<AuditLog[]> {
    return sqliteDb.select().from(auditLogs).orderBy(desc(auditLogs.timestamp)).all();
  }

  async createBackup(data: InsertBackup): Promise<Backup> {
    const id = randomUUID();
    const now = new Date();
    sqliteDb.insert(backups).values({
      id,
      name: data.name,
      createdAt: now,
      createdBy: data.createdBy,
      backupData: data.backupData,
      metadata: data.metadata || null,
    }).run();
    const result = sqliteDb.select().from(backups).where(eq(backups.id, id)).limit(1).all();
    return result[0];
  }

  async getBackups(): Promise<Backup[]> {
    return sqliteDb.select().from(backups).orderBy(desc(backups.createdAt)).all();
  }

  async getBackupById(id: string): Promise<Backup | undefined> {
    const result = sqliteDb.select().from(backups).where(eq(backups.id, id)).limit(1).all();
    return result[0];
  }

  async deleteBackup(id: string): Promise<boolean> {
    sqliteDb.delete(backups).where(eq(backups.id, id)).run();
    return true;
  }

  async getBackupDataForExport(): Promise<{
    imports: Import[];
    dataRows: DataRow[];
    users: Array<{ username: string; role: string; isBanned: boolean | null; passwordHash: string }>;
    auditLogs: AuditLog[];
  }> {
    const allImports = sqliteDb.select().from(imports).where(eq(imports.isDeleted, false)).all();
    const allDataRows = sqliteDb.select().from(dataRows).all();
    const allUsersFromDb = sqliteDb.select().from(users).all();
    const allUsers = allUsersFromDb.map((u) => ({
      username: u.username,
      role: u.role,
      isBanned: u.isBanned,
      passwordHash: u.password,
    }));
    const allAuditLogs = sqliteDb.select().from(auditLogs).all();

    return {
      imports: allImports,
      dataRows: allDataRows,
      users: allUsers,
      auditLogs: allAuditLogs,
    };
  }

  async restoreFromBackup(backupData: {
    imports: Import[];
    dataRows: DataRow[];
    users: Array<{ username: string; role: string; isBanned: boolean | null; passwordHash?: string }>;
    auditLogs: AuditLog[];
  }): Promise<{ success: boolean; stats: { imports: number; dataRows: number; users: number; auditLogs: number } }> {
    const stats = {
      imports: 0,
      dataRows: 0,
      users: 0,
      auditLogs: 0,
    };

    for (const imp of backupData.imports) {
      const existing = await this.getImportById(imp.id);
      if (!existing) {
        sqliteDb.insert(imports).values(imp).run();
        stats.imports++;
      }
    }

    for (const row of backupData.dataRows) {
      const existing = sqliteDb.select().from(dataRows).where(eq(dataRows.id, row.id)).limit(1).all();
      if (existing.length === 0) {
        sqliteDb.insert(dataRows).values(row).run();
        stats.dataRows++;
      }
    }

    for (const userData of backupData.users) {
      const existingUser = await this.getUserByUsername(userData.username);
      if (!existingUser && userData.passwordHash) {
        const id = randomUUID();
        sqliteDb.insert(users).values({
          id,
          username: userData.username,
          password: userData.passwordHash,
          role: userData.role,
          isBanned: userData.isBanned,
        }).run();
        stats.users++;
      }
    }

    for (const log of backupData.auditLogs) {
      const existing = sqliteDb.select().from(auditLogs).where(eq(auditLogs.id, log.id)).limit(1).all();
      if (existing.length === 0) {
        sqliteDb.insert(auditLogs).values(log).run();
        stats.auditLogs++;
      }
    }

    return { success: true, stats };
  }

  async getDashboardSummary(): Promise<{
    totalUsers: number;
    activeSessions: number;
    loginsToday: number;
    totalDataRows: number;
    totalImports: number;
    bannedUsers: number;
  }> {
    const allUsers = sqliteDb.select().from(users).all();
    const activeActivities = sqliteDb.select().from(userActivity).where(eq(userActivity.isActive, true)).all();
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const allActivities = sqliteDb.select().from(userActivity).all();
    const loginsToday = allActivities.filter(a => {
      if (!a.loginTime) return false;
      const loginDate = new Date(a.loginTime);
      return loginDate >= today;
    }).length;
    
    const allDataRows = sqliteDb.select().from(dataRows).all();
    const allImports = sqliteDb.select().from(imports).where(eq(imports.isDeleted, false)).all();
    const bannedUsersList = sqliteDb.select().from(users).where(eq(users.isBanned, true)).all();
    
    return {
      totalUsers: allUsers.length,
      activeSessions: activeActivities.length,
      loginsToday,
      totalDataRows: allDataRows.length,
      totalImports: allImports.length,
      bannedUsers: bannedUsersList.length,
    };
  }

  async getLoginTrends(days: number = 7): Promise<Array<{ date: string; logins: number; logouts: number }>> {
    const result: Array<{ date: string; logins: number; logouts: number }> = [];
    const now = new Date();
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);
      
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const dateStr = `${year}-${month}-${day}`;
      
      const allActivities = sqliteDb.select().from(userActivity).all();
      const logins = allActivities.filter(a => {
        if (!a.loginTime) return false;
        const loginDate = new Date(a.loginTime);
        return loginDate >= date && loginDate < nextDate;
      }).length;
      
      const logouts = allActivities.filter(a => {
        if (!a.logoutTime) return false;
        const logoutDate = new Date(a.logoutTime);
        return logoutDate >= date && logoutDate < nextDate;
      }).length;
      
      result.push({ date: dateStr, logins, logouts });
    }
    
    return result;
  }

  async getTopActiveUsers(limit: number = 10): Promise<Array<{ username: string; role: string; loginCount: number; lastLogin: string | null }>> {
    const allActivities = sqliteDb.select().from(userActivity).all();
    const userLoginCounts = new Map<string, { count: number; role: string; lastLogin: Date | null }>();
    
    for (const activity of allActivities) {
      if (!activity.loginTime) continue;
      const key = activity.username.toLowerCase();
      const existing = userLoginCounts.get(key);
      const loginDate = new Date(activity.loginTime);
      
      if (existing) {
        existing.count++;
        if (!existing.lastLogin || loginDate > existing.lastLogin) {
          existing.lastLogin = loginDate;
        }
      } else {
        userLoginCounts.set(key, {
          count: 1,
          role: activity.role,
          lastLogin: loginDate,
        });
      }
    }
    
    const sorted = Array.from(userLoginCounts.entries())
      .map(([username, data]) => ({
        username,
        role: data.role,
        loginCount: data.count,
        lastLogin: data.lastLogin?.toISOString() || null,
      }))
      .sort((a, b) => b.loginCount - a.loginCount)
      .slice(0, limit);
    
    return sorted;
  }

  async getPeakHours(): Promise<Array<{ hour: number; count: number }>> {
    const hours = Array.from({ length: 24 }, (_, i) => ({ hour: i, count: 0 }));
    const allActivities = sqliteDb.select().from(userActivity).all();
    
    for (const activity of allActivities) {
      if (!activity.loginTime) continue;
      const loginHour = new Date(activity.loginTime).getHours();
      hours[loginHour].count++;
    }
    
    return hours;
  }

  async getRoleDistribution(): Promise<Array<{ role: string; count: number }>> {
    const allUsers = sqliteDb.select().from(users).all();
    const roleCount = new Map<string, number>();
    
    for (const user of allUsers) {
      const count = roleCount.get(user.role) || 0;
      roleCount.set(user.role, count + 1);
    }
    
    return Array.from(roleCount.entries()).map(([role, count]) => ({ role, count }));
  }
}

export const storage = new SQLiteStorage();
