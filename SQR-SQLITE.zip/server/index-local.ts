import express, { type Request, Response, NextFunction } from "express";
import { createServer } from "http";
import path from "path";
import fs from "fs";
import { WebSocketServer, WebSocket } from "ws";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { storage as sqliteStorage } from "./storage-sqlite";

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

const JWT_SECRET = process.env.SESSION_SECRET || "sqr-local-secret-key-2025";
const connectedClients = new Map<string, WebSocket>();

function parseBrowser(userAgent: string | null | undefined): string {
  if (!userAgent) return "Unknown";
  
  const ua = userAgent;
  const uaLower = ua.toLowerCase();
  
  const extractVersion = (pattern: RegExp): string => {
    const match = ua.match(pattern);
    if (match && match[1]) {
      const parts = match[1].split('.');
      return parts[0];
    }
    return "";
  };
  
  if (uaLower.includes("edg/")) {
    const ver = extractVersion(/Edg\/(\d+[\d.]*)/i);
    return ver ? `Edge ${ver}` : "Edge";
  }
  if (uaLower.includes("edge/")) {
    const ver = extractVersion(/Edge\/(\d+[\d.]*)/i);
    return ver ? `Edge ${ver}` : "Edge";
  }
  if (uaLower.includes("opr/")) {
    const ver = extractVersion(/OPR\/(\d+[\d.]*)/i);
    return ver ? `Opera ${ver}` : "Opera";
  }
  if (uaLower.includes("opera/")) {
    const ver = extractVersion(/Opera\/(\d+[\d.]*)/i);
    return ver ? `Opera ${ver}` : "Opera";
  }
  if (uaLower.includes("brave")) {
    const ver = extractVersion(/Brave\/(\d+[\d.]*)/i) || extractVersion(/Chrome\/(\d+[\d.]*)/i);
    return ver ? `Brave ${ver}` : "Brave";
  }
  if (uaLower.includes("duckduckgo")) {
    const ver = extractVersion(/DuckDuckGo\/(\d+[\d.]*)/i);
    return ver ? `DuckDuckGo ${ver}` : "DuckDuckGo";
  }
  if (uaLower.includes("vivaldi")) {
    const ver = extractVersion(/Vivaldi\/(\d+[\d.]*)/i);
    return ver ? `Vivaldi ${ver}` : "Vivaldi";
  }
  if (uaLower.includes("firefox/") || uaLower.includes("fxios/")) {
    const ver = extractVersion(/Firefox\/(\d+[\d.]*)/i) || extractVersion(/FxiOS\/(\d+[\d.]*)/i);
    return ver ? `Firefox ${ver}` : "Firefox";
  }
  if (uaLower.includes("safari/") && !uaLower.includes("chrome/") && !uaLower.includes("chromium/")) {
    const ver = extractVersion(/Version\/(\d+[\d.]*)/i);
    return ver ? `Safari ${ver}` : "Safari";
  }
  if (uaLower.includes("chrome/") || uaLower.includes("crios/") || uaLower.includes("chromium/")) {
    const ver = extractVersion(/Chrome\/(\d+[\d.]*)/i) || extractVersion(/CriOS\/(\d+[\d.]*)/i);
    return ver ? `Chrome ${ver}` : "Chrome";
  }
  if (uaLower.includes("msie") || uaLower.includes("trident/")) {
    const ver = extractVersion(/MSIE (\d+[\d.]*)/i) || extractVersion(/rv:(\d+[\d.]*)/i);
    return ver ? `Internet Explorer ${ver}` : "Internet Explorer";
  }
  
  return "Unknown";
}

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

interface AuthenticatedRequest extends Request {
  user?: { username: string; role: string };
}

function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Token required" });
  }

  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      return res.status(403).json({ message: "Invalid token" });
    }
    req.user = decoded;
    next();
  });
}

function requireRole(...roles: string[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }
    next();
  };
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", mode: "sqlite" });
});

async function handleLogin(req: Request, res: Response) {
  try {
    const { username, password, fingerprint, pcName, browser } = req.body;

    const user = await sqliteStorage.getUserByUsername(username);
    if (!user) {
      await sqliteStorage.createAuditLog({
        action: "LOGIN_FAILED",
        performedBy: username,
        details: "User not found",
      });
      return res.status(401).json({ message: "Invalid credentials" });
    }

    if (user.isBanned) {
      await sqliteStorage.createAuditLog({
        action: "LOGIN_FAILED_BANNED",
        performedBy: username,
        details: "User is banned",
      });
      return res.status(403).json({ message: "Account is banned", banned: true });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      await sqliteStorage.createAuditLog({
        action: "LOGIN_FAILED",
        performedBy: username,
        details: "Invalid password",
      });
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: "24h" }
    );

    const browserName = parseBrowser(browser || req.headers["user-agent"]);
    const activity = await sqliteStorage.createActivity({
      username: user.username,
      role: user.role,
      pcName: pcName || null,
      browser: browserName,
      fingerprint: fingerprint || null,
      ipAddress: req.ip || req.socket.remoteAddress || null,
    });

    await sqliteStorage.createAuditLog({
      action: "LOGIN_SUCCESS",
      performedBy: username,
      details: `Login from ${browserName}`,
    });

    res.json({
      token,
      username: user.username,
      role: user.role,
      user: { username: user.username, role: user.role },
      activityId: activity.id,
    });
  } catch (error: any) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
}

app.post("/api/login", handleLogin);
app.post("/api/auth/login", handleLogin);

app.post("/api/activity/login", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { username, role, pcName, browser, fingerprint } = req.body;
    const browserName = parseBrowser(browser || req.headers["user-agent"]);
    const activity = await sqliteStorage.createActivity({
      username,
      role,
      pcName: pcName || null,
      browser: browserName,
      fingerprint: fingerprint || null,
      ipAddress: req.ip || req.socket.remoteAddress || null,
    });
    res.json({ activityId: activity.id, success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/activity/logout", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { activityId } = req.body;
    if (activityId) {
      await sqliteStorage.updateActivity(activityId, {
        isActive: false,
        logoutTime: new Date(),
        logoutReason: "USER_LOGOUT",
      });
    }
    await sqliteStorage.createAuditLog({
      action: "LOGOUT",
      performedBy: req.user!.username,
    });
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/activity/all", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const activities = await sqliteStorage.getAllActivities();
    res.json({ activities });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/activity/filter", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const filters: any = {};
    if (req.query.status) {
      filters.status = (req.query.status as string).split(",");
    }
    if (req.query.username) filters.username = req.query.username as string;
    if (req.query.ipAddress) filters.ipAddress = req.query.ipAddress as string;
    if (req.query.browser) filters.browser = req.query.browser as string;
    if (req.query.dateFrom) filters.dateFrom = new Date(req.query.dateFrom as string);
    if (req.query.dateTo) filters.dateTo = new Date(req.query.dateTo as string);
    
    const activities = await sqliteStorage.getFilteredActivities(filters);
    res.json({ activities });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.delete("/api/activity/:id", authenticateToken, requireRole("admin", "superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    await sqliteStorage.deleteActivity(req.params.id);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/activity/kick", authenticateToken, requireRole("admin", "superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { activityId } = req.body;
    console.log(`Activity kick request for activityId: ${activityId}`);
    
    if (activityId) {
      const activity = await sqliteStorage.getActivityById(activityId);
      await sqliteStorage.updateActivity(activityId, {
        isActive: false,
        logoutTime: new Date(),
        logoutReason: "KICKED",
      });
      if (activity) {
        const normalizedUsername = activity.username.toLowerCase();
        const ws = connectedClients.get(normalizedUsername);
        console.log(`WebSocket lookup for activity kick ${normalizedUsername}: ${ws ? 'found' : 'not found'}`);
        
        if (ws && ws.readyState === WebSocket.OPEN) {
          console.log(`Sending kick message to ${activity.username}`);
          ws.send(JSON.stringify({ type: "kicked", reason: "You have been logged out by an administrator." }));
        }
      }
    }
    await sqliteStorage.createAuditLog({
      action: "KICK_USER",
      performedBy: req.user!.username,
    });
    res.json({ success: true });
  } catch (error: any) {
    console.error("Activity kick error:", error);
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/activity/ban", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { activityId } = req.body;
    console.log(`Activity ban request for activityId: ${activityId}`);
    
    if (!activityId) {
      return res.status(400).json({ message: "activityId required" });
    }
    
    const activity = await sqliteStorage.getActivityById(String(activityId));
    if (!activity) {
      return res.status(404).json({ message: "Activity not found" });
    }
    
    const username = activity.username;
    const targetUser = await sqliteStorage.getUserByUsername(username);
    if (targetUser && targetUser.role === "superuser") {
      return res.status(403).json({ message: "Cannot ban a superuser" });
    }
    
    await sqliteStorage.updateUserBan(username, true);
    await sqliteStorage.updateActivity(String(activityId), {
      isActive: false,
      logoutTime: new Date(),
      logoutReason: "BANNED",
    });
    
    const normalizedUsername = username.toLowerCase();
    const ws = connectedClients.get(normalizedUsername);
    console.log(`WebSocket lookup for activity ban ${normalizedUsername}: ${ws ? 'found' : 'not found'}`);
    
    if (ws && ws.readyState === WebSocket.OPEN) {
      console.log(`Sending ban message to ${username}`);
      ws.send(JSON.stringify({ type: "banned", reason: "Your account has been banned." }));
    }
    
    await sqliteStorage.createAuditLog({
      action: "BAN_USER",
      performedBy: req.user!.username,
      targetUser: username,
      details: `Banned session ${activityId}`,
    });
    res.json({ success: true });
  } catch (error: any) {
    console.error("Activity ban error:", error);
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/activity/unban", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { visitorId, username } = req.body;
    
    // Support both old username-based and new visitorId-based unban
    const targetUsername = username || visitorId;
    if (!targetUsername) {
      return res.status(400).json({ message: "username or visitorId required" });
    }
    
    // Try to find user by username first
    let user = await sqliteStorage.getUserByUsername(targetUsername);
    
    // If not found by username, try to find by fingerprint in activities
    if (!user && visitorId) {
      const activities = await sqliteStorage.getAllActivities();
      const matchingActivity = activities.find(a => a.fingerprint === visitorId);
      if (matchingActivity) {
        user = await sqliteStorage.getUserByUsername(matchingActivity.username);
      }
    }
    
    if (user) {
      await sqliteStorage.updateUserBan(user.username, false);
      await sqliteStorage.createAuditLog({
        action: "UNBAN_USER",
        performedBy: req.user!.username,
        targetUser: user.username,
      });
      res.json({ success: true });
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error: any) {
    console.error("Activity unban error:", error);
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/users/banned", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const bannedUsers = await sqliteStorage.getBannedUsers();
    const allActivities = await sqliteStorage.getAllActivities();
    
    const usersWithVisitorId = bannedUsers.map((user: any) => {
      const userActivity = allActivities.find(
        (a: any) => a.username.toLowerCase() === user.username.toLowerCase() && a.fingerprint
      );
      return {
        visitorId: userActivity?.fingerprint || user.username,
        username: user.username,
        role: user.role,
        banInfo: user.banInfo,
      };
    });
    
    res.json({ users: usersWithVisitorId });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/search/columns", authenticateToken, async (req, res) => {
  try {
    const columns = await sqliteStorage.getAllColumnNames();
    res.json(columns);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/auth/logout", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { activityId } = req.body;
    if (activityId) {
      await sqliteStorage.updateActivity(activityId, {
        isActive: false,
        logoutTime: new Date(),
        logoutReason: "USER_LOGOUT",
      });
    }
    await sqliteStorage.createAuditLog({
      action: "LOGOUT",
      performedBy: req.user!.username,
    });
    res.json({ message: "Logged out successfully" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/auth/me", authenticateToken, async (req: AuthenticatedRequest, res) => {
  res.json({ user: req.user });
});

app.post("/api/activity/heartbeat", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { activityId } = req.body;
    if (activityId) {
      await sqliteStorage.updateActivity(activityId, {
        lastActivityTime: new Date(),
      });
    }
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/imports", authenticateToken, async (req, res) => {
  try {
    const allImports = await sqliteStorage.getImports();
    const importsWithRowCount = await Promise.all(
      allImports.map(async (imp) => {
        const rows = await sqliteStorage.getDataRowsByImport(imp.id);
        return { ...imp, rowCount: rows.length };
      })
    );
    res.json({ imports: importsWithRowCount });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/imports", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { name, filename, rows, data } = req.body;
    const dataRows = rows || data || [];
    
    if (!Array.isArray(dataRows) || dataRows.length === 0) {
      return res.status(400).json({ message: "No data rows provided" });
    }
    
    const importRecord = await sqliteStorage.createImport({
      name,
      filename,
      createdBy: req.user?.username,
    });

    for (const row of dataRows) {
      await sqliteStorage.createDataRow({
        importId: importRecord.id,
        jsonData: JSON.stringify(row),
      });
    }

    await sqliteStorage.createAuditLog({
      action: "IMPORT_DATA",
      performedBy: req.user!.username,
      targetResource: name,
      details: `Imported ${dataRows.length} rows from ${filename}`,
    });

    res.json(importRecord);
  } catch (error: any) {
    console.error("Import error:", error);
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/imports/:id", authenticateToken, async (req, res) => {
  try {
    const importRecord = await sqliteStorage.getImportById(req.params.id);
    if (!importRecord) {
      return res.status(404).json({ message: "Import not found" });
    }
    const rows = await sqliteStorage.getDataRowsByImport(req.params.id);
    res.json({ import: importRecord, rows });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/imports/:id/data", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 100, 500);
    const offset = (page - 1) * limit;

    const importRecord = await sqliteStorage.getImportById(req.params.id);
    if (!importRecord) {
      return res.status(404).json({ message: "Import not found" });
    }
    const allRows = await sqliteStorage.getDataRowsByImport(req.params.id);
    const totalRows = allRows.length;
    const totalPages = Math.ceil(totalRows / limit);
    
    const paginatedRows = allRows.slice(offset, offset + limit);
    const parsedRows = paginatedRows.map((row: any) => {
      try {
        return JSON.parse(row.jsonData || row.data || '{}');
      } catch {
        return {};
      }
    });
    
    res.json({ 
      import: importRecord, 
      data: parsedRows, 
      rows: parsedRows,
      pagination: {
        page,
        limit,
        totalRows,
        totalPages,
        hasMore: page < totalPages
      }
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Helper function: Validate Malaysian IC date (YYMMDD)
function isValidMalaysianIC(ic: string): boolean {
  if (!/^\d{12}$/.test(ic)) return false;
  
  // Malaysian phone numbers start with 01 - exclude these
  if (ic.startsWith('01')) return false;
  
  // Extract date parts: YYMMDD
  const mm = parseInt(ic.substring(2, 4), 10);
  const dd = parseInt(ic.substring(4, 6), 10);
  
  // Validate month (01-12)
  if (mm < 1 || mm > 12) return false;
  
  // Validate day (01-31) - basic check
  if (dd < 1 || dd > 31) return false;
  
  // More specific day validation based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (dd > daysInMonth[mm - 1]) return false;
  
  return true;
}

// Column exclusion lists for IC detection
// Note: Avoid generic terms like "NOMBOR" which would exclude valid IC columns
const excludeColumnsFromIC = ['AGREEMENT', 'LOAN', 'ACCOUNT', 'AKAUN', 'PINJAMAN', 'CONTRACT', 'KONTRAK', 
  'REFERENCE', 'TRANSACTION', 'TRANSAKSI', 'PHONE', 'TELEFON', 'MOBILE', 'HANDPHONE', 
  'FAX', 'FAKS', 'E-MONEY'];
const excludeColumnsFromPolice = ['VEHICLE', 'KENDERAAN', 'REGISTRATION', 'PLATE', 'RSTG', 
  'CAR', 'KERETA', 'MOTOR', 'MOTOSIKAL', 'VEH', 'PENDAFTARAN'];

// Helper to split cell values by common delimiters including single spaces
function splitCellValue(val: string): string[] {
  // Remove labels like IC1:, IC2:, NRIC:, NO IC:, etc.
  const withoutLabels = val.replace(/\b(IC\d*|NRIC|NO\.?\s*IC|KAD PENGENALAN|KP)\s*[:=]/gi, ' ');
  // Split by common delimiters: / , ; | newlines AND whitespace (single or multiple)
  return withoutLabels.split(/[\/,;|\n\r\s]+/).map(s => s.trim()).filter(s => s.length > 0);
}

function analyzeDataRows(rows: any[]) {
  const icLelakiSet = new Set<string>();
  const icPerempuanSet = new Set<string>();
  const noPolisSet = new Set<string>();
  const noTenteraSet = new Set<string>();
  const passportMYSet = new Set<string>();
  const passportLuarNegaraSet = new Set<string>();
  const valueCounts: Record<string, number> = {};
  const processedValues = new Set<string>();

  const passportPattern = /^[A-Z]{1,2}\d{6,9}$/i;
  const malaysiaPassportPrefixes = ['A', 'H', 'K', 'Q'];
  const excludePrefixes = ['LOT', 'NO', 'PT', 'KM', 'JLN', 'BLK', 'TMN', 'KG', 'SG', 'BTU', 'RM'];
  
  // Validation functions with minimum digit requirements to avoid false positives
  // Single letter prefix: 5+ digits, Two letters: 4+ digits, Three+: 3+ digits
  const isValidPolisNo = (val: string): boolean => {
    if (/^[PG]\d{5,10}$/i.test(val)) return true;
    if (/^(RF|SW)\d{4,10}$/i.test(val)) return true;
    if (/^(RFT|PDRM|POLIS|POL)\d{3,10}$/i.test(val)) return true;
    return false;
  };
  
  const isValidTenteraNo = (val: string): boolean => {
    if (/^[TM]\d{5,10}$/i.test(val)) return true;
    if (/^(TD|TA|TT)\d{4,10}$/i.test(val)) return true;
    if (/^(TLDM|TUDM|ARMY|ATM|MAF|TEN|MIL)\d{3,10}$/i.test(val)) return true;
    return false;
  };

  rows.forEach((row: any) => {
    try {
      const data = JSON.parse(row.jsonData || row.data || '{}');
      Object.entries(data).forEach(([key, val]) => {
        if (val && typeof val === "string") {
          const keyUpper = key.toUpperCase();
          const isExcludedFromIC = excludeColumnsFromIC.some(excl => keyUpper.includes(excl));
          const isExcludedFromPolice = excludeColumnsFromPolice.some(excl => keyUpper.includes(excl));
          
          // Split cell value to handle multiple IDs per cell
          const fragments = splitCellValue(val.toString());
          
          for (const fragment of fragments) {
            const cleaned = fragment.toUpperCase().replace(/[^A-Z0-9]/g, "");
            if (cleaned.length === 0) continue;
            
            valueCounts[cleaned] = (valueCounts[cleaned] || 0) + 1;
            
            if (processedValues.has(cleaned)) continue;
            processedValues.add(cleaned);
            
            // IC Detection with proper validation
            if (!isExcludedFromIC && isValidMalaysianIC(cleaned)) {
              const lastDigit = parseInt(cleaned.charAt(11), 10);
              if (lastDigit % 2 === 1) {
                icLelakiSet.add(cleaned);
              } else {
                icPerempuanSet.add(cleaned);
              }
            } else if (!isExcludedFromPolice && isValidPolisNo(cleaned)) {
              noPolisSet.add(cleaned);
            } else if (isValidTenteraNo(cleaned)) {
              noTenteraSet.add(cleaned);
            } else if (passportPattern.test(cleaned)) {
              const isExcluded = excludePrefixes.some(prefix => cleaned.startsWith(prefix));
              if (!isExcluded) {
                const firstChar = cleaned.charAt(0);
                if (malaysiaPassportPrefixes.includes(firstChar)) {
                  passportMYSet.add(cleaned);
                } else {
                  passportLuarNegaraSet.add(cleaned);
                }
              }
            }
          }
        }
      });
    } catch {}
  });

  const icLelaki = Array.from(icLelakiSet);
  const icPerempuan = Array.from(icPerempuanSet);
  const noPolis = Array.from(noPolisSet);
  const noTentera = Array.from(noTenteraSet);
  const passportMY = Array.from(passportMYSet);
  const passportLuarNegara = Array.from(passportLuarNegaraSet);

  const duplicateItems = Object.entries(valueCounts)
    .filter(([_, count]) => count > 1)
    .map(([value, count]) => ({ value, count }))
    .sort((a, b) => b.count - a.count);

  // Return only counts and limited samples (no 'all' arrays to save memory)
  return {
    icLelaki: { count: icLelaki.length, samples: icLelaki.slice(0, 50) },
    icPerempuan: { count: icPerempuan.length, samples: icPerempuan.slice(0, 50) },
    noPolis: { count: noPolis.length, samples: noPolis.slice(0, 50) },
    noTentera: { count: noTentera.length, samples: noTentera.slice(0, 50) },
    passportMY: { count: passportMY.length, samples: passportMY.slice(0, 50) },
    passportLuarNegara: { count: passportLuarNegara.length, samples: passportLuarNegara.slice(0, 50) },
    duplicates: { count: duplicateItems.length, items: duplicateItems.slice(0, 50) },
  };
}

app.get("/api/imports/:id/analyze", authenticateToken, async (req, res) => {
  try {
    const importRecord = await sqliteStorage.getImportById(req.params.id);
    if (!importRecord) {
      return res.status(404).json({ message: "Import not found" });
    }
    const rows = await sqliteStorage.getDataRowsByImport(req.params.id);
    const analysis = analyzeDataRows(rows);
    
    res.json({
      import: { id: importRecord.id, name: importRecord.name, filename: importRecord.filename },
      totalRows: rows.length,
      analysis,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analyze/all", authenticateToken, async (req, res) => {
  try {
    const imports = await sqliteStorage.getImports();
    if (imports.length === 0) {
      return res.json({
        totalImports: 0,
        totalRows: 0,
        imports: [],
        analysis: {
          icLelaki: { count: 0, samples: [] },
          icPerempuan: { count: 0, samples: [] },
          noPolis: { count: 0, samples: [] },
          noTentera: { count: 0, samples: [] },
          passportMY: { count: 0, samples: [] },
          passportLuarNegara: { count: 0, samples: [] },
          duplicates: { count: 0, items: [] },
        },
      });
    }

    let allRows: any[] = [];
    const importsWithCounts = await Promise.all(
      imports.map(async (imp: any) => {
        const rows = await sqliteStorage.getDataRowsByImport(imp.id);
        allRows = allRows.concat(rows);
        return { id: imp.id, name: imp.name, filename: imp.filename, rowCount: rows.length };
      })
    );

    const analysis = analyzeDataRows(allRows);

    res.json({
      totalImports: imports.length,
      totalRows: allRows.length,
      imports: importsWithCounts,
      analysis,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.patch("/api/imports/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { name } = req.body;
    const updated = await sqliteStorage.updateImportName(req.params.id, name);
    if (!updated) {
      return res.status(404).json({ message: "Import not found" });
    }
    await sqliteStorage.createAuditLog({
      action: "UPDATE_IMPORT",
      performedBy: req.user!.username,
      targetResource: name,
    });
    res.json(updated);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.patch("/api/imports/:id/rename", authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const { name } = req.body;
    const updated = await sqliteStorage.updateImportName(req.params.id, name);
    if (!updated) {
      return res.status(404).json({ message: "Import not found" });
    }
    await sqliteStorage.createAuditLog({
      action: "UPDATE_IMPORT",
      performedBy: req.user!.username,
      targetResource: name,
    });
    res.json(updated);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.delete("/api/imports/:id", authenticateToken, requireRole("admin", "superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const importRecord = await sqliteStorage.getImportById(req.params.id);
    const deleted = await sqliteStorage.deleteImport(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Import not found" });
    }
    await sqliteStorage.createAuditLog({
      action: "DELETE_IMPORT",
      performedBy: req.user!.username,
      targetResource: importRecord?.name || req.params.id,
    });
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/search", authenticateToken, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || typeof q !== "string") {
      return res.status(400).json({ message: "Query parameter 'q' is required" });
    }
    const rawResults = await sqliteStorage.searchDataRows(q);
    const parsedResults = rawResults.map((row: any) => {
      try {
        return JSON.parse(row.jsonData || row.data || '{}');
      } catch {
        return row;
      }
    });
    const headers = parsedResults.length > 0 ? Object.keys(parsedResults[0]) : [];
    res.json({ results: parsedResults, headers });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/search/advanced", authenticateToken, async (req, res) => {
  try {
    const { filters, logic } = req.body;
    const rawResults = await sqliteStorage.advancedSearchDataRows(filters, logic || "AND");
    const parsedResults = rawResults.map((row: any) => {
      try {
        return JSON.parse(row.jsonData || row.data || '{}');
      } catch {
        return row;
      }
    });
    const headers = parsedResults.length > 0 ? Object.keys(parsedResults[0]) : [];
    res.json({ results: parsedResults, headers });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/columns", authenticateToken, async (req, res) => {
  try {
    const columns = await sqliteStorage.getAllColumnNames();
    res.json(columns);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/activities", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const activities = await sqliteStorage.getAllActivities();
    res.json(activities);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/activities/active", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const activities = await sqliteStorage.getActiveActivities();
    res.json(activities);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/activities/filter", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const filters = req.body;
    const activities = await sqliteStorage.getFilteredActivities(filters);
    res.json(activities);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/admin/kick", authenticateToken, requireRole("admin", "superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { username, activityId } = req.body;
    console.log(`Kick request for user: ${username}, activityId: ${activityId}`);
    
    if (activityId) {
      await sqliteStorage.updateActivity(activityId, {
        isActive: false,
        logoutTime: new Date(),
        logoutReason: "KICKED",
      });
    }

    const normalizedUsername = username.toLowerCase();
    const ws = connectedClients.get(normalizedUsername);
    console.log(`WebSocket lookup for ${normalizedUsername}: ${ws ? 'found' : 'not found'}`);
    console.log(`Connected clients: ${Array.from(connectedClients.keys()).join(', ')}`);
    
    if (ws && ws.readyState === WebSocket.OPEN) {
      console.log(`Sending kick message to ${username}`);
      ws.send(JSON.stringify({ type: "kicked", reason: "You have been logged out by an administrator." }));
    } else {
      console.log(`Cannot send kick message: WebSocket ${ws ? 'not open' : 'not found'}`);
    }

    await sqliteStorage.createAuditLog({
      action: "KICK_USER",
      performedBy: req.user!.username,
      targetUser: username,
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("Kick error:", error);
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/admin/ban", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { username } = req.body;
    console.log(`Ban request for user: ${username}`);
    
    await sqliteStorage.updateUserBan(username, true);
    await sqliteStorage.deactivateUserActivities(username, "BANNED");

    const normalizedUsername = username.toLowerCase();
    const ws = connectedClients.get(normalizedUsername);
    console.log(`WebSocket lookup for ban ${normalizedUsername}: ${ws ? 'found' : 'not found'}`);
    
    if (ws && ws.readyState === WebSocket.OPEN) {
      console.log(`Sending ban message to ${username}`);
      ws.send(JSON.stringify({ type: "banned", reason: "Your account has been banned." }));
    } else {
      console.log(`Cannot send ban message: WebSocket ${ws ? 'not open' : 'not found'}`);
    }

    await sqliteStorage.createAuditLog({
      action: "BAN_USER",
      performedBy: req.user!.username,
      targetUser: username,
    });

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/admin/unban", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { username } = req.body;
    await sqliteStorage.updateUserBan(username, false);
    await sqliteStorage.createAuditLog({
      action: "UNBAN_USER",
      performedBy: req.user!.username,
      targetUser: username,
    });
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/admin/banned", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const bannedUsers = await sqliteStorage.getBannedUsers();
    res.json({ users: bannedUsers });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/users", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const allUsers: any[] = [];
    const usernames = ["superuser", "admin1", "user1"];
    for (const username of usernames) {
      const user = await sqliteStorage.getUserByUsername(username);
      if (user) {
        allUsers.push({ id: user.id, username: user.username, role: user.role, isBanned: user.isBanned });
      }
    }
    res.json(allUsers);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/users", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { username, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await sqliteStorage.createUser({ username, password: hashedPassword, role });
    await sqliteStorage.createAuditLog({
      action: "CREATE_USER",
      performedBy: req.user!.username,
      targetUser: username,
      details: `Created user with role: ${role}`,
    });
    res.json({ id: user.id, username: user.username, role: user.role, isBanned: user.isBanned });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/audit-logs", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const logs = await sqliteStorage.getAuditLogs();
    res.json({ logs: logs });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/audit-logs/stats", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const logs = await sqliteStorage.getAuditLogs();
    const stats = {
      totalLogs: logs.length,
      todayLogs: logs.filter((l: any) => {
        const logDate = new Date(l.timestamp || l.createdAt);
        const today = new Date();
        return logDate.toDateString() === today.toDateString();
      }).length,
      actionBreakdown: {} as Record<string, number>,
    };
    logs.forEach((log: any) => {
      const action = log.action || 'UNKNOWN';
      stats.actionBreakdown[action] = (stats.actionBreakdown[action] || 0) + 1;
    });
    res.json(stats);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analyze/all", authenticateToken, requireRole("admin", "superuser"), async (req, res) => {
  try {
    const imports = await sqliteStorage.getImports();
    const allData: any[] = [];
    
    for (const imp of imports) {
      const rows = await sqliteStorage.getDataRowsByImport(imp.id);
      rows.forEach((row: any) => {
        try {
          const parsed = JSON.parse(row.jsonData || row.data || '{}');
          allData.push({ ...parsed, _importId: imp.id, _importName: imp.name });
        } catch (e) {}
      });
    }
    
    const icPattern = /^\d{6}-\d{2}-\d{4}$/;
    const analysis = {
      totalRecords: allData.length,
      totalImports: imports.length,
      icNumbers: {
        valid: 0,
        invalid: 0,
        missing: 0,
      },
      duplicates: [] as any[],
      columnStats: {} as Record<string, { filled: number; empty: number }>,
    };
    
    const icCounts: Record<string, number> = {};
    
    allData.forEach((row) => {
      const icField = row['NO. KAD PENGENALAN'] || row['IC'] || row['ic'] || row['no_kp'] || row['NO KP'];
      if (icField) {
        const ic = String(icField).trim();
        if (icPattern.test(ic)) {
          analysis.icNumbers.valid++;
        } else {
          analysis.icNumbers.invalid++;
        }
        icCounts[ic] = (icCounts[ic] || 0) + 1;
      } else {
        analysis.icNumbers.missing++;
      }
      
      Object.keys(row).forEach((key) => {
        if (!key.startsWith('_')) {
          if (!analysis.columnStats[key]) {
            analysis.columnStats[key] = { filled: 0, empty: 0 };
          }
          if (row[key] !== null && row[key] !== undefined && String(row[key]).trim() !== '') {
            analysis.columnStats[key].filled++;
          } else {
            analysis.columnStats[key].empty++;
          }
        }
      });
    });
    
    Object.entries(icCounts).forEach(([ic, count]) => {
      if (count > 1) {
        analysis.duplicates.push({ ic, count });
      }
    });
    
    res.json(analysis);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/debug/websocket-clients", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const clients = Array.from(connectedClients.keys());
    res.json({ count: clients.length, clients });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.delete("/api/audit-logs/cleanup", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { olderThanDays } = req.body;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - (olderThanDays || 30));
    
    const logs = await sqliteStorage.getAuditLogs();
    let deletedCount = 0;
    
    for (const log of logs) {
      if (log.timestamp) {
        const logDate = new Date(log.timestamp);
        if (logDate < cutoffDate) {
          deletedCount++;
        }
      }
    }
    
    await sqliteStorage.createAuditLog({
      action: "CLEANUP_AUDIT_LOGS",
      performedBy: req.user!.username,
      details: `Cleanup requested for logs older than ${olderThanDays} days`,
    });
    
    res.json({ success: true, deletedCount, message: `Cleanup completed` });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analytics/summary", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const summary = await sqliteStorage.getDashboardSummary();
    res.json(summary);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analytics/login-trends", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const days = parseInt(req.query.days as string) || 7;
    const trends = await sqliteStorage.getLoginTrends(days);
    res.json(trends);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analytics/top-users", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 10;
    const topUsers = await sqliteStorage.getTopActiveUsers(limit);
    res.json(topUsers);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analytics/peak-hours", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const peakHours = await sqliteStorage.getPeakHours();
    res.json(peakHours);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/analytics/role-distribution", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const distribution = await sqliteStorage.getRoleDistribution();
    res.json(distribution);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/backups", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const backups = await sqliteStorage.getBackups();
    res.json({ backups: backups });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/backups", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const { name } = req.body;
    const backupData = await sqliteStorage.getBackupDataForExport();
    const backup = await sqliteStorage.createBackup({
      name,
      createdBy: req.user!.username,
      backupData: JSON.stringify(backupData),
      metadata: JSON.stringify({ timestamp: new Date().toISOString() }),
    });
    await sqliteStorage.createAuditLog({
      action: "CREATE_BACKUP",
      performedBy: req.user!.username,
      targetResource: name,
    });
    res.json(backup);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/backups/:id", authenticateToken, requireRole("superuser"), async (req, res) => {
  try {
    const backup = await sqliteStorage.getBackupById(req.params.id);
    if (!backup) {
      return res.status(404).json({ message: "Backup not found" });
    }
    res.json(backup);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/backups/:id/restore", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const backup = await sqliteStorage.getBackupById(req.params.id);
    if (!backup) {
      return res.status(404).json({ message: "Backup not found" });
    }
    const backupData = JSON.parse(backup.backupData);
    const result = await sqliteStorage.restoreFromBackup(backupData);
    await sqliteStorage.createAuditLog({
      action: "RESTORE_BACKUP",
      performedBy: req.user!.username,
      targetResource: backup.name,
      details: JSON.stringify(result.stats),
    });
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

app.delete("/api/backups/:id", authenticateToken, requireRole("superuser"), async (req: AuthenticatedRequest, res) => {
  try {
    const backup = await sqliteStorage.getBackupById(req.params.id);
    const deleted = await sqliteStorage.deleteBackup(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Backup not found" });
    }
    await sqliteStorage.createAuditLog({
      action: "DELETE_BACKUP",
      performedBy: req.user!.username,
      targetResource: backup?.name || req.params.id,
    });
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

wss.on("connection", (ws, req) => {
  const url = new URL(req.url!, `http://${req.headers.host}`);
  const token = url.searchParams.get("token");

  if (token) {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as { username: string };
      const normalizedUsername = decoded.username.toLowerCase();
      connectedClients.set(normalizedUsername, ws);
      console.log(`WebSocket: ${decoded.username} connected (${connectedClients.size} sessions)`);

      ws.on("close", () => {
        connectedClients.delete(normalizedUsername);
        console.log(`WebSocket: ${decoded.username} disconnected (${connectedClients.size} sessions)`);
      });
    } catch (err) {
      console.log("WebSocket: Invalid token, closing connection");
      ws.close();
    }
  }
});

function serveStatic() {
  const cwd = process.cwd();
  
  const possiblePaths = [
    "dist-local/public",
    "dist-local\\public",
    "dist/public",
    "dist\\public",
  ];
  
  console.log(`  Working directory: ${cwd}`);
  
  let foundPath: string | null = null;
  let foundIndex: string | null = null;
  
  for (const relPath of possiblePaths) {
    const fullPath = path.resolve(cwd, relPath);
    const indexFile = path.join(fullPath, "index.html");
    
    console.log(`  Checking: ${fullPath}`);
    
    try {
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isDirectory()) {
        const files = fs.readdirSync(fullPath);
        console.log(`    Found ${files.length} files: ${files.slice(0, 5).join(", ")}${files.length > 5 ? "..." : ""}`);
        
        if (fs.existsSync(indexFile)) {
          foundPath = fullPath;
          foundIndex = indexFile;
          break;
        }
      }
    } catch (err: any) {
      console.log(`    Error: ${err.message}`);
    }
  }
  
  if (foundPath && foundIndex) {
    console.log(`  Frontend: Serving from ${foundPath}`);
    app.use(express.static(foundPath));
    
    app.use((req, res, next) => {
      if (req.path.startsWith("/api") || req.path.startsWith("/ws")) {
        return next();
      }
      res.sendFile(foundIndex!);
    });
    
    console.log(`  Frontend: OK`);
  } else {
    console.log("");
    console.log("  ERROR: Frontend files not found!");
    console.log("  Please run: npm run build:local");
    console.log(`  Expected location: ${path.resolve(cwd, "dist-local/public")}`);
    
    app.use((req, res) => {
      if (!req.path.startsWith("/api")) {
        res.status(404).send(`
          <html>
            <body style="font-family: sans-serif; padding: 40px;">
              <h1>Frontend Not Built</h1>
              <p>Please run: <code>npm run build:local</code></p>
              <p>Then restart the server.</p>
            </body>
          </html>
        `);
      }
    });
  }
}

async function startServer() {
  console.log("");
  console.log("=========================================");
  console.log("  SQR - SUMBANGAN QUERY RAHMAH");
  console.log("  Mode: Local (SQLite Database)");
  console.log("=========================================");
  console.log("");

  console.log("  Database: SQLite - OK");
  
  serveStatic();

  const PORT = parseInt(process.env.PORT || "5000", 10);
  const HOST = "0.0.0.0";

  server.listen(PORT, HOST, () => {
    console.log("");
    console.log("=========================================");
    console.log(`  Server berjalan di port ${PORT}`);
    console.log("");
    console.log("  Buka browser:");
    console.log(`    http://localhost:${PORT}`);
    console.log("");
    console.log("  Untuk akses dari PC lain (LAN):");
    console.log(`    http://[IP-KOMPUTER]:${PORT}`);
    console.log("=========================================");
    console.log("");
  });
}

startServer();
